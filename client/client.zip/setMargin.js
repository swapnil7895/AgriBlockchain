
//   if (typeof window.web3 !== undefined ){
//     let web3js = new Web3(window.web3.getProvider());
// }
  


const ethEnabled = () => {
  if (window.ethereum) {
    window.web3 = new Web3(window.ethereum);
    window.ethereum.enable();
    //window.eth_requestAccounts();
    return true;
  }
  return console.log(false);
}
ethEnabled();



    //const web3 = new Web3('http://127.0.0.1:7545');
    const contract = new web3.eth.Contract(
      AgriBlockAbi,
      AgriBlockAddress
    );
  
   let defaultAccount;
   web3.eth.getAccounts()
      .then(
          accounts => defaultAccount=accounts[0]
          );
    contract.defaultAccount=defaultAccount;
  
  const setMarginButton=document.getElementById("setm-b");
  const handleSetMargin = ()=>{
    var dm=document.getElementById("dm-id").value;
    var sdm=document.getElementById("sdm-id").value;
  
    contract.methods.setProfitPercentage(dm,sdm).send
   ({
     from: web3.eth.currentProvider.selectedAddress,
     gasPrice: 10000,
     gas:1000000 
   })
   .on('confirmation', c => { alert(c) })
   .on('transactionHash', h => { alert("Transaction hash :  " + h + " Price set done") })
   .on('error', err => { alert(err + " Failed, try value greater than 100 / try using your account") })
   .then
   (
     result=>
     {
       console.log(result)
      }
   )
   
   
  }
  setMarginButton.addEventListener("click",handleSetMargin);
  
  
  
  
